﻿using System.Diagnostics;
using System;
using System.IO;
using System.Text;
using UnityEngine;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;

/// <summary>
/// Handles post Unity build actions, i.e. copy config files to build directory
/// </summary>
public class ConfigMoveProcessor : IPostprocessBuildWithReport
{
    public int callbackOrder { get { return 0; } }
    public void OnPostprocessBuild(BuildReport report)
    {
        string fileName = Path.GetFileName(report.summary.outputPath);
        string path = report.summary.outputPath.Replace(fileName, "");
        string datapath = PlayerSettings.productName + "_Data/";
        
        if (File.Exists(path + datapath + "ExperimentConfig.json")) 
            File.Delete(path + datapath + "ExperimentConfig.json");

        FileUtil.CopyFileOrDirectory("Assets/ExperimentConfig.json", path + datapath + "ExperimentConfig.json");

        if (File.Exists(path + datapath + "TaskConfig.json")) 
            File.Delete(path + datapath + "TaskConfig.json");

        FileUtil.CopyFileOrDirectory("Assets/TaskConfig.json", path + datapath + "TaskConfig.json");

        UnityEngine.Debug.Log("Copied config files to " + path + datapath);
    }
}